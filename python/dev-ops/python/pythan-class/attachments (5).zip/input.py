print ("Demo for input statement")
print ("------------------------")
x=input("enter the value for x:")
x=float(x)
y=input("enter the value for y:")
y=float(y)
z=x/y
print (z)
