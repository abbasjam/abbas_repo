print ("Set Manipulations")
print ("-----------------")
x={1,2,3,4,5,6}
print ("Given x is :",x)
x.discard(5)
print ("after discard(5):",x)
x.discard(100)
print ("After discard(100):",x)
