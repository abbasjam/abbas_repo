print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

y=x.capitalize()
print ("After Capitalize() x is :",x)
print ("After Capitalize() y is :",y)
