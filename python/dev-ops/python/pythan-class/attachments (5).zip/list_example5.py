print ("List Manipulations")
print ("------------------")

x=[100,"BSS",99.9,89+9j,True,"Python","Vani","Karthi","Anand"]
print ("Value of x is :",x)
 
if "Anand" in x:
    print ("Found")
else:
    print ("Not Found")
