print ("Example for if else")
print ("--------------------")

x=int(input("enter the number:"))
if x>0:
    print ("Given x is :",x)
    print ("It is Positive")
else:
    print ("Given x is :",x)
    print ("It is negative")
print ("After if it continuessss.....")
