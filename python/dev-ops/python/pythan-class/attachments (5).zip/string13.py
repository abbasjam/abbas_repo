print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

if x.startswith('This'):
    print ("Yes!!!!!!!String is startswith This")
else:
    print ("Not startswith")

