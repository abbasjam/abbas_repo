print ("Demo for output statement")
print ("------------------------")
x=23
y=34
z="BSS"
print (x)
print (x,y,z)
print ("value of x is ",x)
print ("Value of x is ",x,", valiue of y is ",y," and value of z is ",z)

