print ("Functions")
print ("----------")

def addition(x,y):
    z=x+y
    print ("x is:",x)
    print ("y is:",y)
    print ("Added Value is:",z) 



addition(10,20)


a=int(input("Enter the First Number:"))
b=int(input("enter the SecondNumber:"))
addition(a,b)


