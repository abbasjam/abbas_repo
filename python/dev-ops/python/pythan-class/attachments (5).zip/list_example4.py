print ("List Manipulations")
print ("------------------")

x=[100,"BSS",99.9,89+9j,True,"Python","Vani","Karthi","Anand"]
print ("Value of x is :",x)

print ("Value of x[-1] is :",x[-1])

i=-1
l=len(x)
while i>-l:
    print (x[i])
    i=i+(-1)

