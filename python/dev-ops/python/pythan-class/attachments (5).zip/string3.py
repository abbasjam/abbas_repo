print ("String Manipulations")
print ("-------------------")

x="Brain Stack solutions"
print ("Value of x is:",x)

if 'Brain' in x:
    print ("Found")
else:
    print ("Not found")
