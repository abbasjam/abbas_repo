print ("List Manipulations")
print ("------------------")

x=[100,"BSS",99.9,89+9j,True,"Python","Vani","Karthi","Anand"]
print ("Value of x is :",x)

x1=x[:3]
x2=x[3:]
x3=x[1:10:3]
print ("Sliced list x1 is[:3] :",x1)
print ("Sliced list x2 is [3:]:",x2)
print ("Sliced list x3 is [1:10:2] is:",x3)
