print ("Example for simple if")
print ("--------------------")

x=int(input("enter the number:"))
if x>0:
    print ("Given x is :",x)
    print ("It is Positive")
print ("After if it continuessss.....")
