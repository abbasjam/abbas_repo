import functions  as f
a=f.addition(1,2,3)
print ("Added value is :",a)
