print ("List Manipulations")
print ("------------------")

x=[100,"BSS",99.9,89+9j,"Python",100,200,100,567,100,"CSS"]
print ("Given List is:",x)

x.reverse()
print ("Reversed list is :",x)

y=[12,1,45,23,11,6,7]
y.sort()
print ("given y is:",y)
print ("After sorting y is :",y)

z=["vani","karthi","anand"]
print ("Given z is :",z)
z.sort()
print ("After Sorting :",z)

a=[1,2,3,4,5]
print ("Given a is :",a)
b=a.copy()
print ("Copied list b is :",b)
