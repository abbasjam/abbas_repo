print ("List Manipulations")
print ("------------------")

x=[100,99.9,100]
y=[12,13,14]
print ("Given List is:",x)
print ("Given y is:",y)
z=x+y
print ("Added list is :",z)

