print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

if x.islower():
    print ("String Contains only lower case letters ")
else:
    print ("one or more chars are not in lowercase")

