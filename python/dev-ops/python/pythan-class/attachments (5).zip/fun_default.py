print ("Functions")
print ("----------")

def addition(x=30,y=45):
    z=x+y
    return z 



ans=addition(12,15)
print ("Added value is :",ans)
ans1=addition(15)
print ("Added value is :",ans1)
ans2=addition()
print ("Added value is :",ans2)

