print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

if x.isalnum():
    print ("String Contains only alphabets or numbers or combinations of both")
else:
    print ("one or more chars are not alphabets or numbers")

