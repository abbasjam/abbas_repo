i=1
while i>=10:
    print ("BSS")
    i=i+1 
print ("Out of loop")

