print ("Dictionary Manipulation")
print ("-----------------------")
y={'Rollno':100,'Name':"Vani",'Mark':99}
print ("value of y is:",y)
k=y.keys()
print ("all the keys are :",k)
v=y.values()
print ("all the Values are :",v)
for i in v:
    print (i)
