print ("String Manipulations")
print ("-------------------")
'''This is demo program for string Manipulation
Done by K.Vani
Date :14.12.2019'''

x="Brain Stack solutions"
y='''BSS - Chennai
Python Class
November Batch'''
print ("Value of x is:",x)
print ("Value of y is:",y)

