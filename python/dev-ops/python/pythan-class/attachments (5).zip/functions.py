def addition(*x):
    print (x)   
    s=0
    for i in x:
        s=s+i
    return s
    

