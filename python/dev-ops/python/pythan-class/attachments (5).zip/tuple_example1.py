print ("Tuple Manipulations")
print ("-------------------")

x=(123,234,"Vani",78,90.8,89,876)
print ("Given Tuple is:",x)

'''x[1]="BSS"
print ("after Modifying:",x)'''

y=x[:3]
print ("After slicing y is:",y)
