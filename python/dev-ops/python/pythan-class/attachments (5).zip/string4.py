print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

if x.isalpha():
    print ("String Contains only alphabets")
else:
    print ("one or more chars are not alphabets")

