print ("List Manipulations")
print ("------------------")

x=[100,"BSS",99.9,89+9j,"Python",100,200,100,567,100,"CSS"]
print ("Given List is:",x)

c=x.count(100)
print ("iNumbewr of occurence of 100 is :",c)



p=x.index(100)
print ("position of 100 is ",p)
