print ("Functions")
print ("----------")

def addition():
    a=int(input("Enter the First Number:"))
    b=int(input("enter the SecondNumber:"))
    z=a+b
    return z 



ans=addition()
print ("Added value is :",ans)



