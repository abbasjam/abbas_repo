print ("Dictionary Manipulation")
print ("-----------------------")
y={'Rollno':100,'Name':"Vani",'Mark':99}
print ("value of y is:",y)


if 'Rollno' in y:
    print ("Found")
else:
    print ("Not Found")
