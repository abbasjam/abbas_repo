print ("Functions")
print ("----------")

def addition(x,y):
    z=x+y
    print ("x is:",x)
    print ("y is:",y)
    return z



ans=addition(10,20)
print("Added Value is :",ans)

a=int(input("Enter the First Number:"))
b=int(input("enter the SecondNumber:"))
ans1=addition(a,b)
print ("Added value is :",ans1)

