print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

if x.isspace():
    print ("String Contains only spaces ")
else:
    print ("one or more chars are not spaces")

