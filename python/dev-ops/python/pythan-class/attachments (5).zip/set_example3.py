print ("Set Manipulations")
print ("-----------------")
x={1,2,3,4,5,6}
y={1,2,3,490,50,10,20}
print ("Given x is :",x)
print ("given y is :",y)
z=x.union(y)
print ("Union of x and y is:",z)
print ("Union using operator:",x|y)
