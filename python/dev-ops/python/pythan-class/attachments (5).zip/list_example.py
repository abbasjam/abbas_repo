print ("List Manipulations")
print ("------------------")

x=[]
x1=[12,13,14,15,16]
x2=[100,"BSS",99.9,89+9j,True]
print ("Value of x is :",x)
print ("Value of x1 is :",x1)
print ("Value of x2 is :",x2)

print ("@nd position value is :",x2[2])

x2[1]="Brain Stack Solutions - Chennai"
print ("After Modification :",x2)

