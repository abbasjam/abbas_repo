print ("Set Manipulations")
print ("-----------------")
x={1,2,3,4,5,6}
print ("Given x is :",x)
x.add(7)
print ("After add():",x)
x.update([10,20,30,1])
print ("After update():",x)
