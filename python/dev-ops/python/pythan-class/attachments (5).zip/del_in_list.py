print ("List Manipulations")
print ("------------------")

x=[100,99.9,100]
print ("Given List is:",x)

del x[1]
print ("after del statement:",x)

del x
print ("after deleting :",x)
