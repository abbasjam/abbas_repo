import functions 
a=functions.addition(1,2,3)
print ("Added value is :",a)
