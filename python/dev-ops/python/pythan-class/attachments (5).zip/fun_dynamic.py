print ("Functions")
print ("----------")

def addition(x,y):
    z=x+y
    return z
def addition1(p,q,r):
    z1=p+q+r
    return z1

a=addition(20,10)
print ("Added value is:",a)
b=addition1(4,5,6)
print ("Added value is :",b)
