print ("List Manipulations")
print ("------------------")

x=[100,"BSS",99.9,89+9j,True]
print ("Value of x is :",x)

print ("Using While loop")
print ("-----------------")
i=0
while i<5:
    print (x[i])
    i=i+1

