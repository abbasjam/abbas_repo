print ("List Manipulations")
print ("------------------")

x=[100,99.9,100,200,100,567,100]
print ("Given List is:",x)
l=len(x)
ma=max(x)
mi=min(x)
su=sum(x)
print ("Total  number of elements are:",l)
print ("Maximum value is:",ma)
print("Minimum value is:",mi)
print("sum of the list is:",su)

