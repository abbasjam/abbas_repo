print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

if x.isdigit():
    print ("String Contains only  numbers ")
else:
    print ("one or more chars are not  numbers")

