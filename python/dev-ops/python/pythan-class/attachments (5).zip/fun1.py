print ("Functions")
print ("----------")

def addition():
    x=int(input("Enter the first Number:"))
    y=int(input("Enter the Second Number:"))
    z=x+y
    print ("Added value is :",z)


addition()
addition()
addition()

