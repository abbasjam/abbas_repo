import os
os.system("clear")
os.system ("ls -l")


