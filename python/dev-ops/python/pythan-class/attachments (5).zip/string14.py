print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

if x.endswith('.txt'):
    print ("Yes!!!!!!!text file")
else:
    print ("Not textfile")

