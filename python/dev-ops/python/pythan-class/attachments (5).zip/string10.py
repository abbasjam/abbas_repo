print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

y=x.lower()
print ("After lower() x is :",x)
print ("After lower() y is :",y)
