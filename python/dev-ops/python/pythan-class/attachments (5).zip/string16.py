print ("String Manipulations")
print ("-------------------")

x=input("Enter the String:")
print ("Given String is:",x)

y=x.split(',')
print ("After split() y is:",y)
