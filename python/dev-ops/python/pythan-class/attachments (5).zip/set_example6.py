print ("Set Manipulations")
print ("-----------------")
x={1,2,3,4,5,6}
y={1,2,3,490,50,10,20}
print ("Given x is :",x)
print ("given y is :",y)
z=x.symmetric_difference(y)
print ("Symmeteric_Difference of x and y is:",z)
print ("Symmeteric_Difference using operator:",y^x)
