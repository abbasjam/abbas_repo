print ("Demo program for input()")
print ("------------------------")

x=input()
y=input()
z=x+y
print (z)
