print ("Demo print options")
print ("------------------")

x=123
y=234
z="BSS"
print ("value of x is ",x," value of y is ",y,"and value of z is ",z)
print ("value of x is {} , y is {} and z is {}".format(x,y,z))
print ("I Love {} , {} and {} Programming".format("C","C++","Python"))
print ("I Love {2}, {0} and {1} Programming".format("C","C++","Python"))
        
