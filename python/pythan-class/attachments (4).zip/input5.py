print ("Demo program for input()")
print ("------------------------")

x=float(input("Enter the Value for x:"))
y=float(input("Enter the Value for y:"))
z=x+y
print (z)
