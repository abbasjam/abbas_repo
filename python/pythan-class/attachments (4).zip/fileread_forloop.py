f=open("demo.txt","r")
for x in f:
    print (x)
