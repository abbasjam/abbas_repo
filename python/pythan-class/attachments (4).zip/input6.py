print ("Demo program for input()")
print ("------------------------")

x=complex(input("Enter the Value for x:"))
y=complex(input("Enter the Value for y:"))
z=x+y
print (z)
