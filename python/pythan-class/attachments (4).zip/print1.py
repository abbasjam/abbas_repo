x=123
y=34
z=x+y
print ("Addition Process")
print ("---------------")
print (x)
print (y)
print (z)

print ("Addition process ")
print ("-----------------")
print ("x = ",x)
print ("y = ",y)
print ("z = ",z)

print ("value of x is ",x," value of y is :",y," and value of z is :",z)


print (x,y,z)
