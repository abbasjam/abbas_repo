print ("Demo print options")
print ("------------------")

x=123
y=234
z="BSS"
print (x,y,z)
print (x,y,z,sep=',')
print (x,y,z)
print ("Hai welcome!!!!",end='@')
print (x,y,z)
print ("Hai!!!  all Welcome to programming Environment!!!!!!",file=open("output.txt","a"))
