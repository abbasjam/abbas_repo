print ("Example for if else if ")
print ("------------------------")

x=int(input("enter the number:"))
if x>0:
    print ("Given x is :",x)
    print ("It is Positive")
elif x<0:
    print ("Given x is :",x)
    print ("It is negative")
else:
    print ("given x is :",x)
    print ("It is zero")
print ("After if it continuessss.....")
