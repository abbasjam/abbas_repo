x=45
y=7
z=x/y
print (z)
