print ("Demo program for input()")
print ("------------------------")

x=input("Enter the Value for x:")
y=input("Enter the Value for y:")
z=x+y
print (z)
