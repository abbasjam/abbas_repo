print ("Demo program for input()")
print ("------------------------")

x=int(input("Enter the Value for x:"))
y=int(input("Enter the Value for y:"))
z=x+y
print (z)
