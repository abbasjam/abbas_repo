print ("Welcome to Python World!!!!")
x=100
y=200
z= x*y
print (z)
