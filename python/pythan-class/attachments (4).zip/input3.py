print ("Demo program for input()")
print ("------------------------")
x=input("Enter the Value for x:")
y=input("Enter the Value for y:")
x=int(x)
y=int(y)
z=x+y
print (z)
