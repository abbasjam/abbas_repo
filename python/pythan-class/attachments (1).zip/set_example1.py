print ("Set Manipulations")
print ("-----------------")
x={1,2,3,4,5,6}
print ("Given x is :",x)
x.remove(5)
print ("after remove(5):",x)
x.remove(100)
print ("After remove(100):",x)
