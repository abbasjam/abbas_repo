print ("Functions")
print ("----------")

def addition(x,y):
    z=x+y
    z1=x-y
    z2=x*y
    return z,z1,z2


a,s,m=addition(20,10)
print( "added value is :",a)
print("Subtracted value is:",s)
print("Multiplied value is:",m)

